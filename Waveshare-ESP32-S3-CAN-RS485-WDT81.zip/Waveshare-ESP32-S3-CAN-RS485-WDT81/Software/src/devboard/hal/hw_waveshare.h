#ifndef __HW_WAVESHARE_H__
#define __HW_WAVESHARE_H__

#include "hal.h"

/*
  Waveshare ESP32-S3-RS485-CAN - GPIO Pin Map
  Verified against official schematic (ESP32-S3-RS485-CAN-Schematic.pdf)

  CAN TX      : IO15 (GPIO15) -> TJA1051T transceiver TXD input
  CAN RX      : IO16 (GPIO16) -> TJA1051T transceiver RXD output
  RS485 TX    : IO17 (GPIO17) -> SP3485EN DI   (TXD1 on schematic)
  RS485 RX    : IO18 (GPIO18) -> SP3485EN RO   (RXD1 on schematic)
  RS485 EN    : IO21 (GPIO21) -> SP3485EN RE/DE (RS485_EN on schematic)

  GPIO1  : J4 connector, Positive Contactor relay
  GPIO2  : J4 connector, Precharge relay
*/

class WaveshareHal : public Esp32Hal {
 public:
  const char* name() { return "Waveshare ESP32-S3 CAN/RS485"; }

  virtual void set_default_configuration_values() {
    BatteryEmulatorSettingsStore settings;
    if (!settings.settingExists("CANFREQ")) {
      settings.saveUInt("CANFREQ", 16);
    }
  }

  // CAN Pins (verified: IO15=TXD->transceiver, IO16=RXD<-transceiver)
  virtual gpio_num_t CAN_TX_PIN() { return GPIO_NUM_15; }
  virtual gpio_num_t CAN_RX_PIN() { return GPIO_NUM_16; }

  // RS485 Pins (verified: IO17=TXD1=DI, IO18=RXD1=RO, IO21=RS485_EN)
  virtual gpio_num_t RS485_TX_PIN() { return GPIO_NUM_17; }
  virtual gpio_num_t RS485_RX_PIN() { return GPIO_NUM_18; }
  virtual gpio_num_t RS485_EN_PIN() { return GPIO_NUM_21; }

  // Contactors mapped to J4 expansion port
  virtual gpio_num_t POSITIVE_CONTACTOR_PIN() { return GPIO_NUM_1; }
  virtual gpio_num_t PRECHARGE_PIN()           { return GPIO_NUM_2; }
  virtual gpio_num_t NEGATIVE_CONTACTOR_PIN() { return GPIO_NUM_NC; }
  virtual gpio_num_t SECOND_BATTERY_CONTACTORS_PIN() { return GPIO_NUM_NC; }
  virtual gpio_num_t TRIPLE_BATTERY_CONTACTORS_PIN() { return GPIO_NUM_NC; }

  // Misc
  virtual gpio_num_t BMS_POWER() { return GPIO_NUM_NC; }

  // LED 
  // Kept as GPIO_NUM_NC 
  virtual gpio_num_t LED_PIN() { return GPIO_NUM_NC; }
  virtual uint8_t LED_MAX_BRIGHTNESS() { return 255; }

  std::vector<comm_interface> available_interfaces() {
    return {comm_interface::RS485, comm_interface::CanNative};
  }
};

#endif
