/*  Uses a simple CT clamp to measure current
 *  ESP32 ADCs are not very accurate outside of linear region
 *  To start in the linear region use a 150mV offset
 *  Use a 100 nF capacitor on the input pin to reduce noise (optional but recommended)
 */

#include "CHADEMO-CT.h"
#include "../datalayer/datalayer.h"
#include "../devboard/utils/events.h"
#include "Arduino.h"
#include "CHADEMO-BATTERY.h"
#include "Shunt.h"

#ifdef UNIT_TEST
// provide minimal stub so unit tests can compile
typedef enum { ADC_0db = 0, ADC_2_5db, ADC_6db, ADC_11db } adc_attenuation_t;
#endif

// Ensure valid values at run-time
// User can update all these values via Settings page
float ct_clamp_offset_mV = -1.0;
uint16_t ct_clamp_nominal_voltage_dV = 40;
uint16_t ct_clamp_nominal_current_A = 100;
bool ct_invert_current = false;
adc_attenuation_enum ct_clamp_pin_atten = adc_attenuation_enum::ADC_11db;
extern const char* name_for_adc_attenuation(adc_attenuation_enum type) {
  switch (type) {
    case adc_attenuation_enum::ADC_0db:
      return "a)   0dB 0-950mV";
    case adc_attenuation_enum::ADC_2_5db:
      return "b) 2.5dB 0-1250mV";
    case adc_attenuation_enum::ADC_6db:
      return "c)   6dB 0-1750mV";
    case adc_attenuation_enum::ADC_11db:
      return "d)  11dB 0-3100mV";
    default:
      return nullptr;
  }
}

static float Amperes;          // Floating point with current in Amperes
static float Voltage = -1.0f;  // Voltage not available

// CT parameters, need to be updated for the specific CT clamp used
// These settings are for a Tamura L03S100D15 CT clamp
// https://www.tamuracorp.com/global/products/download/pdf/06_L03SxxxD15_e.pdf
// At 20A the output is 0.8V, so 0Db attenuation can be used to get better resolution at low currents.  The voltage offset is set to 0.15V to start in the linear region of the CT clamp.

// use a dedicated variable for the pin so that this file does not rely
// on a class member name that only exists inside ChademoBattery.  The
// value is fetched from the HAL so it will match whatever board is in
// use.
static gpio_num_t ct_pin;
static bool ct_pin_initialized = false;

// Included for future use
float get_measured_voltage_ct() {
  return Voltage;
}

// +ve is charging, -ve is discharging, use invert setting to flip if needed
float get_measured_current_ct() {
  if (!ct_pin_initialized) {
    return 0;
  }

  float CT_V_offset = ct_clamp_offset_mV / 1000.0f;                 // Convert from mV to Volts
  float CT_V_nominal = (float)ct_clamp_nominal_voltage_dV / 10.0f;  // Convert from dV to Volts
  float CT_A_nominal = (float)ct_clamp_nominal_current_A;           // in Amperes

  // sample the CT pin multiple times and average to reduce noise
  float pin_V = 0.0f;
  for (int i = 0; i < 10; i++) {
    pin_V += (float)analogReadMilliVolts(ct_pin);
  }
  pin_V = (pin_V / 10.0f) / 1000.0f;
  Amperes = (pin_V - CT_V_offset) * (CT_A_nominal / CT_V_nominal);
  if (ct_invert_current) {
    Amperes = -Amperes;
  }
  return Amperes;
}

void setup_ct(void) {
  // Initialize ct_pin from HAL if not already done
  if (!ct_pin_initialized) {
    ct_pin = esp32hal->CHADEMO_CT_PIN();
    ct_pin_initialized = true;
  }

  // reserve the pin with the HAL so we detect conflicts early
  if (!esp32hal->alloc_pins("CHAdeMO CT", ct_pin)) {
    return;
  }

  // Configure as adc
  // Set resolution to 12 bits (0-4095) - Default
  pinMode(ct_pin, INPUT);
  analogRead(ct_pin);  // Avoids error if attenuation is set before first read
  analogSetPinAttenuation(ct_pin, (adc_attenuation_t)ct_clamp_pin_atten);
  if (!(bool)digitalRead(esp32hal->CHADEMO_PIN_4()) && ct_clamp_offset_mV < 0) {
    ct_clamp_offset_mV = (float)analogReadMilliVolts(ct_pin);
  }

  char shunt_protocol[32];
  snprintf(shunt_protocol, sizeof(shunt_protocol), "%dA CT Clamp", (int)ct_clamp_nominal_current_A);
  strncpy(datalayer.system.info.shunt_protocol, shunt_protocol, 31);
  datalayer.system.info.shunt_protocol[31] = '\0';
}
