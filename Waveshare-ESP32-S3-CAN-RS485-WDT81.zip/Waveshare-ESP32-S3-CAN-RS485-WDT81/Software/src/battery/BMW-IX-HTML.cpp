#include "BMW-IX-HTML.h"
#include "BMW-IX-BATTERY.h"

String BmwIXHtmlRenderer::getDTCDescription(uint32_t code) {
  switch (code) {
#ifndef SMALL_FLASH_DEVICE
    case 0x020700:
      return "SME: Transport mode active";
    case 0x020708:
      return "SME: Control unit is not encoded";
    case 0x020709:
      return "SME: Encoded data does not match vehicle";
    case 0x020740:
      return "SME, voltage supply: Undervoltage";
    case 0x020780:
      return "SME: Certificates (Type 1) not ready";
    case 0x020785:
      return "SME: Control unit not in field mode";
    case 0x21F001:
      return "High-voltage battery unit, coolant shutoff valve: Line disconnection";
    case 0x21F00F:
      return "High-voltage battery unit, coolant shutoff valve: Line disconnection";
    case 0x21F121:
      return "High-voltage battery unit, control unit: internal defective alarm function";
    case 0x21F306:
      return "High-voltage battery unit, control unit, idle time estimation: Estimation failed";
    case 0x21F37E:
      return "Impact detection: Crash detected due to ACSM signal";
    case 0x21F38F:
      return "SME: internal control unit errors (Group fault software)";
    case 0x21F393:
      return "High-voltage battery unit, multiple fault: Transport restricting fault memory active";
    case 0x21F3F0:
      return "High-voltage battery unit: Expansion of the operating range for the state of charge active";
    case 0x21F436:
      return "High-voltage battery unit, high-voltage safety battery terminal: High-voltage-minus not disconnected due "
             "to unsuccessful actuation";
    case 0x21F44F:
      return "High-voltage battery unit, SME: Pyrofuse ignited or faulty actuation";
    case 0x21F4B5:
      return "High-voltage battery unit, voltage and current sensor: Power-down requested";
    case 0x21F4ED:
      return "High-voltage battery unit, voltage and current sensor: Line protection, threshold value exceeded";
    case 0x3B001A:
      return "High-voltage battery unit: Multiple faults, high-voltage system cannot be activated";
    case 0xCAD450:
      return "No message (- 0x125), SME receiver, CCU transmitter";
    case 0xCAD454:
      return "No message (- 0x16E), SME receiver, CCU transmitter";
    case 0xCAD4B0:
      return "No message (vehicle speed, 0x1A1), receiver SME, transmitter DSC";
    case 0xCAD6D8:
      return "No message (- 0x91), SME receiver, EME transmitter";

    default:
      return "";
#else
    default:
      return "Current BE hardware does not support details. Please upgrade to large flash BE";  // Detailed DTC descriptions not available on 4MB low flash devices. The above text takes up a massive amount of flash!
#endif
  }
}

String BmwIXHtmlRenderer::get_status_html() {
  String content;

  // Power & Voltage Section
  content +=
      "<h3 style='color: #1e88e5; border-bottom: 2px solid #1e88e5; padding-bottom: 5px;'>⚡ Power & Voltage</h3>";
  content += "<div style='margin-left: 15px;'>";
  content +=
      "<h4>Battery Voltage (After Contactor): " + String(batt.get_battery_voltage_after_contactor()) + " dV</h4>";
  content += "<h4>Max Design Voltage: " + String(datalayer.battery.info.max_design_voltage_dV) + " dV</h4>";
  content += "<h4>Min Design Voltage: " + String(datalayer.battery.info.min_design_voltage_dV) + " dV</h4>";
  content += "<h4>T30 Terminal Voltage: " + String(batt.get_T30_Voltage()) + " mV</h4>";
  content += "<h4>Allowed Charge Power: " + String(datalayer.battery.status.max_charge_power_W) + " W</h4>";
  content += "<h4>Allowed Discharge Power: " + String(datalayer.battery.status.max_discharge_power_W) + " W</h4>";
  content += "<h4>BMS Allowed Charge Amps: " + String(batt.get_allowable_charge_amps()) + " A</h4>";
  content += "<h4>BMS Allowed Discharge Amps: " + String(batt.get_allowable_discharge_amps()) + " A</h4>";
  content += "</div>";

  // Cell Information Section
  content +=
      "<h3 style='color: #8e24aa; border-bottom: 2px solid #8e24aa; padding-bottom: 5px;'>📊 Cell Information</h3>";
  content += "<div style='margin-left: 15px;'>";
  content += "<h4>Detected Cell Count: " + String(datalayer.battery.info.number_of_cells) + "</h4>";
  content += "<h4>Max Cell Design Voltage: " + String(datalayer.battery.info.max_cell_voltage_mV) + " mV</h4>";
  content += "<h4>Min Cell Design Voltage: " + String(datalayer.battery.info.min_cell_voltage_mV) + " mV</h4>";
  content += "<h4>Min Cell Voltage Data Age: " + String(batt.get_min_cell_voltage_data_age()) + " ms</h4>";
  content += "<h4>Max Cell Voltage Data Age: " + String(batt.get_max_cell_voltage_data_age()) + " ms</h4>";
  content += "</div>";

  // Battery Status Section
  content += "<h3 style='color: #35b1ab; border-bottom: 2px solid #35b1ab; padding-bottom: 5px;'>⚖️ Battery Status</h3>";
  content += "<div style='margin-left: 15px;'>";
  content += "<h4>Balancing: ";
  switch (batt.get_balancing_status()) {
    case 0:
      content += "No Balancing Mode Active</h4>";
      break;
    case 1:
      content += "<span style='color: #43a047;'>Voltage-Controlled Balancing Mode</span></h4>";
      break;
    case 2:
      content +=
          "<span style='color: #43a047;'>Time-Controlled Balancing Mode with Demand Calculation at End of "
          "Charging</span></h4>";
      break;
    case 3:
      content +=
          "<span style='color: #43a047;'>Time-Controlled Balancing Mode with Demand Calculation at Resting "
          "Voltage</span></h4>";
      break;
    case 4:
      content += "No Balancing Mode Active (Qualifier Invalid)</h4>";
      break;
    default:
      content += "Unknown</h4>";
  }
  // Energy Saving Mode Status
  content += "<h4>Energy Saving Mode: ";
  int energy_mode = batt.get_energy_saving_mode_status();
  switch (energy_mode) {
    case 0:
      content += "No Operating Mode Set (Normal)</h4>";
      break;
    case 1:
      content += "<span style='color: #fb8c00;'>Production Mode Active</span></h4>";
      break;
    case 2:
      content += "<span style='color: #fb8c00;'>Transport Mode Active</span></h4>";
      break;
    case 3:
      content += "<span style='color: #fb8c00;'>Flash Mode Active</span></h4>";
      break;
    default:
      if (energy_mode >= 4 && energy_mode <= 16) {
        content += "<span style='color: #fb8c00;'>Extended Operating Mode " + String(energy_mode) + "</span></h4>";
      } else {
        content += "Unknown (" + String(energy_mode) + ")</h4>";
      }
      break;
  }
  content += "</div>";

  // Safety Systems Section
  content += "<h3 style='color: #e53935; border-bottom: 2px solid #e53935; padding-bottom: 5px;'>🛡️ Safety Systems</h3>";
  content += "<div style='margin-left: 15px;'>";
  content += "<h4>HVIL Status: ";
  switch (batt.get_hvil_status()) {
    case 0:
      content += "<span style='color: #d32f2f;'>⚠ Error (Loop Open)</span></h4>";
      break;
    case 1:
      content += "OK (Loop Closed)</h4>";
      break;
    default:
      content += "Unknown</h4>";
  }
  content += "<h4>Pyro Status PSS1: ";
  switch (batt.get_pyro_status_pss1()) {
    case 0:
      content += "Value Invalid</h4>";
      break;
    case 1:
      content += "<span style='color: #d32f2f;'>⚠ Successfully Blown</span></h4>";
      break;
    case 2:
      content += "<span style='color: #ff6f00;'>Disconnected</span></h4>";
      break;
    case 3:
      content += "Not Activated - Pyro Intact</h4>";
      break;
    case 4:
      content += "Unknown</h4>";
      break;
    default:
      content += "Unknown</h4>";
  }
  content += "<h4>Pyro Status PSS4: ";
  switch (batt.get_pyro_status_pss4()) {
    case 0:
      content += "Value Invalid</h4>";
      break;
    case 1:
      content += "<span style='color: #d32f2f;'>⚠ Successfully Blown</span></h4>";
      break;
    case 2:
      content += "<span style='color: #ff6f00;'>Disconnected</span></h4>";
      break;
    case 3:
      content += "Not Activated - Pyro Intact</h4>";
      break;
    case 4:
      content += "Unknown</h4>";
      break;
    default:
      content += "Unknown</h4>";
  }
  content += "<h4>Pyro Status PSS6: ";
  switch (batt.get_pyro_status_pss6()) {
    case 0:
      content += "Value Invalid</h4>";
      break;
    case 1:
      content += "<span style='color: #d32f2f;'>⚠ Successfully Blown</span></h4>";
      break;
    case 2:
      content += "<span style='color: #ff6f00;'>Disconnected</span></h4>";
      break;
    case 3:
      content += "Not Activated - Pyro Intact</h4>";
      break;
    case 4:
      content += "Unknown</h4>";
      break;
    default:
      content += "Unknown</h4>";
  }
  content += "</div>";

  // Isolation Monitoring Section
  content +=
      "<h3 style='color: #fb8c00; border-bottom: 2px solid #fb8c00; padding-bottom: 5px;'>🔋 Isolation "
      "Monitoring</h3>";
  content += "<div style='margin-left: 15px;'>";
  content +=
      "<h4>Isolation Positive: " + String(batt.get_iso_safety_positive()) + " kΩ (2147483647 = maximum/invalid)</h4>";
  content +=
      "<h4>Isolation Negative: " + String(batt.get_iso_safety_negative()) + " kΩ (2147483647 = maximum/invalid)</h4>";
  content +=
      "<h4>Isolation Parallel: " + String(batt.get_iso_safety_parallel()) + " kΩ (2147483647 = maximum/invalid)</h4>";
  content += "</div>";

  // Diagnostics Section
  content += "<h3 style='color: #757575; border-bottom: 2px solid #757575; padding-bottom: 5px;'>🔧 Diagnostics</h3>";
  content += "<div style='margin-left: 15px;'>";

  // Convert uptime to days:hours:minutes:seconds format
  unsigned long uptime_seconds = batt.get_bms_uptime();
  unsigned long days = uptime_seconds / 86400;
  unsigned long hours = (uptime_seconds % 86400) / 3600;
  unsigned long minutes = (uptime_seconds % 3600) / 60;
  unsigned long seconds = uptime_seconds % 60;

  content += "<h4>BMS Uptime: " + String(days) + "d " + String(hours) + "h " + String(minutes) + "m " +
             String(seconds) + "s</h4>";
  content += "</div>";

  // Diagnostic Trouble Codes Section
  content +=
      "<h3 style='color: #27b06c; border-bottom: 2px solid #27b06c; padding-bottom: 5px;'>🔧 Diagnostic Trouble "
      "Codes</h3>";
  content += "<div style='margin-left: 15px; margin-right: 15px;'>";

  if (datalayer_extended.bmwix.dtc_last_read_millis == 0) {
    // No DTC read has been performed yet
    content +=
        "<p style='color: #ff9800;'>ℹ DTCs have not been read yet. Click 'Read DTC' to scan for fault codes.</p>";
  } else if (datalayer_extended.bmwix.dtc_read_failed) {
    content += "<p style='color: #d32f2f;'>⚠ Last DTC read failed or not supported</p>";
  } else if (datalayer_extended.bmwix.dtc_count == 0) {
    content += "<p style='color: #4CAF50;'>✓ No DTCs present</p>";
  } else {
    content += "<p><strong>DTC Count:</strong> " + String(datalayer_extended.bmwix.dtc_count) + "</p>";

    // Convert last read time to days:hours:minutes:seconds format
    unsigned long last_read_seconds = (millis() - datalayer_extended.bmwix.dtc_last_read_millis) / 1000;
    unsigned long read_days = last_read_seconds / 86400;
    unsigned long read_hours = (last_read_seconds % 86400) / 3600;
    unsigned long read_minutes = (last_read_seconds % 3600) / 60;
    unsigned long read_seconds = last_read_seconds % 60;

    content += "<p><strong>Last Read:</strong> ";
    if (read_days > 0) {
      content += String(read_days) + "d ";
    }
    if (read_hours > 0 || read_days > 0) {
      content += String(read_hours) + "h ";
    }
    content += String(read_minutes) + "m " + String(read_seconds) + "s ago</p>";

    content += "<div style='overflow-x: auto; margin-top: 10px; margin-bottom: 15px;'>";
    content +=
        "<table style='width: auto; margin: 0 auto; border-collapse: separate; border-spacing: 0; border: 1px solid "
        "#ddd; border-radius: 8px; overflow: hidden;'>";

    content += "<thead>";
    content += "<tr style='background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white;'>";
    content += "<th style='padding: 12px 15px; text-align: left; font-weight: 600;'>DTC Code</th>";
    content += "<th style='padding: 12px 15px; text-align: left; font-weight: 600;'>Status</th>";
    content += "<th style='padding: 12px 15px; text-align: left; font-weight: 600;'>Description</th>";
    content += "</tr>";
    content += "</thead>";

    content += "<tbody>";

    for (int i = 0; i < datalayer_extended.bmwix.dtc_count; i++) {
      uint32_t code = datalayer_extended.bmwix.dtc_codes[i];
      uint8_t status = datalayer_extended.bmwix.dtc_status[i];

      char dtcStr[12];
      sprintf(dtcStr, "%06lX", code);

      String statusStr = "Stored";
      String statusColor = "#757575";

      if (status & 0x08) {
        statusStr = "Confirmed";
        statusColor = "#ff6f00";
      }

      if (status & 0x01) {
        statusStr = "Active";
        statusColor = "#d32f2f";
      }

      String description = getDTCDescription(code);
      if (description.length() == 0) {
        description = "Unknown";
      }

      content += "<tr>";
      content +=
          "<td style='padding: 12px 15px; border-top: 1px solid #e0e0e0; font-family: monospace; font-size: 1.1em; "
          "font-weight: 600;'>" +
          String(dtcStr) + "</td>";
      content += "<td style='padding: 12px 15px; border-top: 1px solid #e0e0e0; color: " + statusColor +
                 "; font-weight: 500;'>" + statusStr + "</td>";
      content += "<td style='padding: 12px 15px; border-top: 1px solid #e0e0e0; font-size: 0.95em; color: #ddd;'>" +
                 description + "</td>";
      content += "</tr>";
    }

    content += "</tbody>";
    content += "</table>";
    content += "</div>";
  }

  content += "</div>";

  return content;
}
