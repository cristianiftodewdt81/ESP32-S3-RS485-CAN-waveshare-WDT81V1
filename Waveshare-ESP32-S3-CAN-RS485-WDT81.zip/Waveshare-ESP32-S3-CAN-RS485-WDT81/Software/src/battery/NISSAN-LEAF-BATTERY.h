#ifndef NISSAN_LEAF_BATTERY_H
#define NISSAN_LEAF_BATTERY_H

#include "../datalayer/datalayer.h"
#include "../datalayer/datalayer_extended.h"
#include "CanBattery.h"
#include "NISSAN-LEAF-HTML.h"

extern bool user_selected_LEAF_interlock_mandatory;

class NissanLeafBattery : public CanBattery {
 public:
  // Use the default constructor to create the first or single battery.battery_Total_Voltage2
  NissanLeafBattery() {
    datalayer_battery = &datalayer.battery;
    allows_contactor_closing = &datalayer.system.status.battery_allows_contactor_closing;
    datalayer_nissan = &datalayer_extended.nissanleaf;
  }
  // Use this constructor for the second battery.
  NissanLeafBattery(DATALAYER_BATTERY_TYPE* datalayer_ptr, DATALAYER_INFO_NISSAN_LEAF* extended,
                    CAN_Interface targetCan)
      : CanBattery(targetCan) {
    datalayer_battery = datalayer_ptr;
    allows_contactor_closing = nullptr;
    datalayer_nissan = extended;

    battery_Total_Voltage2 = 0;  //Zero out pack voltage to avoid contactor closing before we know value via CAN
  }

  virtual void setup(void);
  virtual void handle_incoming_can_frame(CAN_frame rx_frame);
  virtual void update_values();
  virtual void transmit_can(unsigned long currentMillis);

  bool supports_reset_SOH();
  void reset_SOH() { datalayer_extended.nissanleaf.UserRequestSOHreset = true; }

  bool soc_plausible() {
    // When pack voltage is close to max, and SOC% is still low (<65.0%), SOC is not plausible
    return !((datalayer.battery.status.voltage_dV > (datalayer.battery.info.max_design_voltage_dV - 100)) &&
             (battery_SOC < 650));
  }

  BatteryHtmlRenderer& get_status_renderer() { return renderer; }
  static constexpr const char* Name = "Nissan LEAF battery";

  uint8_t calculate_crc(CAN_frame& frame);

 private:
  static const int MAX_PACK_VOLTAGE_DV = 4040;  //5000 = 500.0V
  static const int MIN_PACK_VOLTAGE_DV = 2600;
  static const int MAX_CELL_DEVIATION_MV = 150;
  static const int MAX_CELL_VOLTAGE_MV = 4250;  //Battery is put into emergency stop if one cell goes over this value
  static const int MIN_CELL_VOLTAGE_MV = 2700;  //Battery is put into emergency stop if one cell goes below this value

  NissanLeafHtmlRenderer renderer;

  bool is_message_corrupt(CAN_frame rx_frame);
  void clearSOH(void);

  DATALAYER_BATTERY_TYPE* datalayer_battery;
  DATALAYER_INFO_NISSAN_LEAF* datalayer_nissan;

  // If not null, this battery decides when the contactor can be closed and writes the value here.
  bool* allows_contactor_closing;

  unsigned long previousMillis10 = 0;   // will store last time a 10ms CAN Message was send
  unsigned long previousMillis40 = 0;   // will store last time a 40ms CAN Message was send
  unsigned long previousMillis100 = 0;  // will store last time a 100ms CAN Message was send
  unsigned long previousMillis500 = 0;  // will store last time a 500ms CAN Message was send
  unsigned long previousMillis10s = 0;  // will store last time a 1s CAN Message was send
  uint8_t mprun10r = 0;                 //counter 0-20 for 0x1F2 message
  uint8_t mprun10 = 0;                  //counter 0-3
  uint8_t mprun100 = 0;                 //counter 0-3
  uint8_t counter_3B8 = 0;              //counter 0-14
  bool flip_3B8 = false;

  static const uint8_t ZE0_BATTERY = 0;
  static const uint8_t AZE0_BATTERY = 1;
  static const uint8_t ZE1_BATTERY = 2;

  // These CAN messages need to be sent towards the battery to keep it alive
  CAN_frame LEAF_1F2 = {.FD = false,
                        .ext_ID = false,
                        .DLC = 8,
                        .ID = 0x1F2,
                        .data = {0x10, 0x64, 0x00, 0xB0, 0x00, 0x1E, 0x00, 0x8F}};
  CAN_frame LEAF_50B = {.FD = false,
                        .ext_ID = false,
                        .DLC = 7,
                        .ID = 0x50B,
                        .data = {0x00, 0x00, 0x06, 0xC0, 0x00, 0x00, 0x00}};
  CAN_frame LEAF_50C = {.FD = false,
                        .ext_ID = false,
                        .DLC = 6,
                        .ID = 0x50C,
                        .data = {0x00, 0x00, 0x00, 0x00, 0x00, 0x00}};
  CAN_frame LEAF_1D4 = {.FD = false,
                        .ext_ID = false,
                        .DLC = 8,
                        .ID = 0x1D4,
                        .data = {0x6E, 0x6E, 0x00, 0x04, 0x07, 0x46, 0xE0, 0x44}};
  // Extra CAN messages for ZE1 batteries
  CAN_frame LEAF_355 = {.FD = false,
                        .ext_ID = false,
                        .DLC = 8,
                        .ID = 0x355,
                        .data = {0x00, 0x00, 0x00, 0x00, 0x10, 0x00, 0x40, 0x00}};
  CAN_frame LEAF_3B8 = {.FD = false, .ext_ID = false, .DLC = 5, .ID = 0x3B8, .data = {0x7F, 0xE8, 0x01, 0x07, 0xFF}};
  CAN_frame LEAF_5C5 = {.FD = false,
                        .ext_ID = false,
                        .DLC = 8,
                        .ID = 0x5C5,
                        .data = {0x40, 0x01, 0x2F, 0x5E, 0x00, 0x00, 0x00, 0x00}};
  CAN_frame LEAF_5EC = {.FD = false, .ext_ID = false, .DLC = 1, .ID = 0x5EC, .data = {0x00}};
  CAN_frame LEAF_626 = {.FD = false,
                        .ext_ID = false,
                        .DLC = 6,
                        .ID = 0x626,
                        .data = {0x02, 0x00, 0xff, 0x1d, 0x20, 0x00}};
  // Active polling messages
  uint8_t PIDgroups[7] = {0x01, 0x02, 0x04, 0x06, 0x83, 0x84, 0x90};
  uint8_t PIDindex = 0;
  CAN_frame LEAF_GROUP_REQUEST = {.FD = false,
                                  .ext_ID = false,
                                  .DLC = 8,
                                  .ID = 0x79B,
                                  .data = {2, 0x21, 1, 0, 0, 0, 0, 0}};
  CAN_frame LEAF_NEXT_LINE_REQUEST = {.FD = false,
                                      .ext_ID = false,
                                      .DLC = 8,
                                      .ID = 0x79B,
                                      .data = {0x30, 1, 0, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF}};

  // The Li-ion battery controller only accepts a multi-message query. In fact, the LBC transmits many
  // groups: the first one contains lots of High Voltage battery data as SOC, currents, and voltage; the second
  // replies with all the battery’s cells voltages in millivolt, the third and the fifth one are still unknown, the
  // fourth contains the four battery packs temperatures, and the last one tells which cell has the shunt active.
  // There are also two more groups: group 61, which replies with lots of CAN messages (up to 48); here we
  // found the SOH value, and group 84 that replies with the HV battery production serial.

  //Nissan LEAF battery parameters from constantly sent CAN
  uint8_t LEAF_battery_Type = ZE0_BATTERY;
  bool battery_can_alive = false;
#define WH_PER_GID 77                          //One GID is this amount of Watt hours
  uint16_t battery_Discharge_Power_Limit = 0;  //Limit in kW
  uint16_t battery_Charge_Power_Limit = 0;     //Limit in kW
  int16_t battery_MAX_POWER_FOR_CHARGER = 0;   //Limit in kW
  int16_t battery_SOC = 500;                   //0 - 100.0 % (0-1000) The real SOC% in the battery
  uint16_t battery_TEMP = 0;                   //Temporary value used in status checks
  uint16_t battery_Wh_Remaining = 0;           //Amount of energy in battery, in Wh
  uint16_t battery_GIDS = 273;                 //Startup in 24kWh mode
  uint16_t battery_MAX = 0;
  uint16_t battery_Max_GIDS = 273;               //Startup in 24kWh mode
  uint16_t battery_StateOfHealth = 99;           //State of health %
  uint16_t battery_Total_Voltage2 = 740;         //Battery voltage (0-450V) [0.5V/bit, so actual range 0-800]
  int16_t battery_Current2 = 0;                  //Battery current (-400-200A) [0.5A/bit, so actual range -800-400]
  int16_t battery_HistData_Temperature_MAX = 6;  //-40 to 86*C
  int16_t battery_HistData_Temperature_MIN = 5;  //-40 to 86*C
  int16_t battery_AverageTemperature = 6;        //Only available on ZE0, in celcius, -40 to +55
  uint8_t battery_Relay_Cut_Request = 0;         //battery_FAIL
  uint8_t battery_Failsafe_Status = 0;           //battery_STATUS
  bool battery_Interlock =
      true;  //Contains info on if HV leads are seated (Note, to use this both HV connectors need to be inserted)
  bool battery_Full_CHARGE_flag = false;  //battery_FCHGEND , Goes to 1 if battery is fully charged
  bool battery_MainRelayOn_flag = false;  //No-Permission=0, Main Relay On Permission=1
  bool battery_Capacity_Empty = false;    //battery_EMPTY, , Goes to 1 if battery is empty
  bool battery_HeatExist = false;      //battery_HEATEXIST, Specifies if battery pack is equipped with heating elements
  bool battery_Heating_Stop = false;   //When transitioning from 0->1, signals a STOP heat request
  bool battery_Heating_Start = false;  //When transitioning from 1->0, signals a START heat request
  bool battery_Batt_Heater_Mail_Send_Request = false;  //Stores info when a heat request is happening

  // Nissan LEAF battery data from polled CAN messages
  uint8_t battery_request_idx = 0;
  uint8_t group_7bb = 0;
  bool stop_battery_query = true;
  uint8_t hold_off_with_polling_10seconds = 2;  //Paused for 20 seconds on startup
  uint16_t battery_cell_voltages[96];           //array with all the cellvoltages
  bool battery_balancing_shunts[96];            //array with all the balancing resistors
  uint8_t battery_cellcounter = 0;
  uint16_t battery_min_max_voltage[2];  //contains cell min[0] and max[1] values in mV
  uint16_t battery_HX = 0;              //Internal resistance
  uint16_t battery_insulation = 0;      //Insulation resistance
  uint16_t battery_temp_raw_1 = 718;
  uint8_t battery_temp_raw_2_highnibble = 0;
  uint16_t battery_temp_raw_2 = 718;
  uint16_t battery_temp_raw_3 = 718;  //This measurement not available on 2013+
  uint16_t battery_temp_raw_4 = 718;
  uint16_t battery_temp_raw_max = 0;
  uint16_t battery_temp_raw_min = 0;
  int16_t battery_temp_polled_max = 0;
  int16_t battery_temp_polled_min = 0;
  uint8_t BatterySerialNumber[15] = {0};  // Stores raw HEX values for ASCII chars
  uint8_t BatteryPartNumber[7] = {0};     // Stores raw HEX values for ASCII chars
  uint8_t BMSIDcode[8] = {0};
  uint8_t stateMachineClearSOH = 0xFF;

#ifndef SMALL_FLASH_DEVICE

  // Clear SOH values

  uint32_t incomingChallenge = 0xFFFFFFFF;
  uint8_t solvedChallenge[8];
  bool challengeFailed = false;

  CAN_frame LEAF_CLEAR_SOH = {.FD = false,
                              .ext_ID = false,
                              .DLC = 8,
                              .ID = 0x79B,
                              .data = {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF}};

#endif
};

#endif
