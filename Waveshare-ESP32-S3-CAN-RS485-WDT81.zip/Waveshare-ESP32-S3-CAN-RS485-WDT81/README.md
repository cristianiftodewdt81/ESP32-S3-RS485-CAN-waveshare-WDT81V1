# Waveshare ESP32-S3 CAN/RS485 Battery Emulator (WDT81 Edition)

This repository contains the stabilized firmware and source code for the **Waveshare ESP32-S3-RS485-CAN** board, specifically optimized for **GoodWe** inverters and **BYD Battery-Box Premium HVS** protocol.

## Hardware Specification: Waveshare ESP32-S3-RS485-CAN
- **MCU:** ESP32-S3
- **CAN TX:** GPIO 15
- **CAN RX:** GPIO 16
- **RS485 TX:** GPIO 17
- **RS485 RX:** GPIO 18
- **RS485 EN:** GPIO 21
- **Contactors (Expansion J4):** GPIO 1 (Positive), GPIO 2 (Precharge)

## Key Fixes in this Edition (WDT81):
1. **Stabilized Handshake**: Modified `BYD-CAN.cpp` to proactively initiate communication. This resolves the "Inverter Missing" issue with GoodWe ET/EH inverters that wait for the battery to speak first.
2. **Boot-Loop Resolution**: Replaced unsafe `analogRead(0)` calls in `TEST-FAKE-BATTERY.cpp` with `esp_random()`, preventing system crashes on the ESP32-S3.
3. **Pin Correction**: Corrected the internal HAL to match the official Waveshare schematic (IO15/IO16 for CAN).
4. **GPIO Safety Guards**: Added checks for `GPIO_NUM_NC` in contactor control to prevent runtime errors when pins are not assigned.

## Installation
- The pre-compiled firmware is available in the `firmware/` directory.
- For development, use **PlatformIO** and the `waveshare_330` environment defined in `platformio.ini`.

## Credits
Based on the **Battery-Emulator** project by Dalathegreat.
Modified and verified by Antigravity AI for WDT81.
